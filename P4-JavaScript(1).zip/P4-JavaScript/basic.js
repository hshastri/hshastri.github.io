function foo(){
  document.getElementsByTagName("h1")[0].innerHTML="Now I know JavaScript!";
  document.getElementById("h1Tag").style.color="blue";

  document.getElementsByTagName("h3")[0].innerHTML="I have awesome homepage!";
  document.getElementById("h3Tag").style.color="green";

  window.alert ("Hello World");
}
